<?php
/**
 * Plugin Name: Yellowstep Elementor Editor
 * Description: Semantic Elementor editing endpoints for Yellowstep/WPVibe development workflows.
 * Version: 1.0.0
 * Author: Yellowstep / WPVibe
 */

if (!defined('ABSPATH')) exit;

final class Yellowstep_Elementor_Editor {
    const NS = 'yellowstep-editor/v1';

    public static function init() {
        add_action('rest_api_init', [__CLASS__, 'register_routes']);
    }

    public static function register_routes() {
        $routes = [
            ['GET',  '/pages',                         'list_pages'],
            ['GET',  '/templates',                     'list_templates'],
            ['GET',  '/structure/(?P<id>\d+)',          'structure'],
            ['GET',  '/semantic-map/(?P<id>\d+)',       'semantic_map'],
            ['GET',  '/snapshots/(?P<id>\d+)',          'snapshots'],
            ['POST', '/duplicate-page',                'duplicate_page'],
            ['POST', '/create-service-page',           'create_service_page'],
            ['POST', '/update-section-field',          'update_section_field'],
            ['POST', '/replace-text',                  'replace_text'],
            ['POST', '/update-card',                   'update_card'],
            ['POST', '/update-faq',                    'update_faq'],
            ['POST', '/update-yoast',                  'update_yoast'],
            ['POST', '/rollback',                      'rollback'],
            ['POST', '/regenerate-css',                'regenerate_css'],
        ];

        foreach ($routes as $r) {
            register_rest_route(self::NS, $r[1], [
                'methods' => $r[0],
                'callback' => [__CLASS__, $r[2]],
                'permission_callback' => [__CLASS__, 'can_edit_pages'],
            ]);
        }
    }

    public static function can_edit_pages() {
        return current_user_can('edit_pages');
    }

    private static function clean_title($post) {
        return html_entity_decode(get_the_title($post), ENT_QUOTES);
    }

    private static function data($post_id) {
        $raw = get_post_meta($post_id, '_elementor_data', true);
        if (!$raw) return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    private static function save_data($post_id, array $data, $note = '') {
        $raw = get_post_meta($post_id, '_elementor_data', true);
        add_post_meta($post_id, '_yellowstep_editor_snapshot', [
            'time' => current_time('mysql'),
            'user_id' => get_current_user_id(),
            'note' => sanitize_text_field($note),
            'data' => $raw,
        ]);
        update_post_meta($post_id, '_elementor_data', wp_slash(wp_json_encode($data)));
        update_post_meta($post_id, '_elementor_edit_mode', 'builder');
        update_post_meta($post_id, '_elementor_version', defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : '');
        self::clear_elementor_cache($post_id);
        clean_post_cache($post_id);
    }

    private static function clear_elementor_cache($post_id = 0) {
        if (class_exists('\Elementor\Plugin')) {
            try { \Elementor\Plugin::$instance->files_manager->clear_cache(); } catch (Throwable $e) {}
        }
        if ($post_id) delete_post_meta($post_id, '_elementor_css');
    }

    private static function post_check($post_id) {
        $post = get_post($post_id);
        if (!$post || !current_user_can('edit_post', $post_id)) {
            return new WP_Error('not_found', 'Post not found or not editable.', ['status' => 404]);
        }
        return $post;
    }

    public static function list_pages($request) {
        $q = new WP_Query([
            'post_type' => ['page'],
            'post_status' => ['publish', 'draft', 'pending', 'private'],
            'posts_per_page' => 200,
            'meta_key' => '_elementor_edit_mode',
            'meta_value' => 'builder',
            'orderby' => 'modified',
            'order' => 'DESC',
            'no_found_rows' => true,
        ]);
        $items = [];
        foreach ($q->posts as $p) {
            $items[] = [
                'id' => $p->ID,
                'title' => self::clean_title($p),
                'slug' => $p->post_name,
                'status' => $p->post_status,
                'modified' => $p->post_modified,
                'link' => get_permalink($p),
            ];
        }
        return rest_ensure_response(['items' => $items]);
    }

    public static function list_templates($request) {
        $q = new WP_Query([
            'post_type' => 'elementor_library',
            'post_status' => ['publish', 'draft', 'private'],
            'posts_per_page' => 200,
            'orderby' => 'modified',
            'order' => 'DESC',
            'no_found_rows' => true,
        ]);
        $items = [];
        foreach ($q->posts as $p) {
            $items[] = [
                'id' => $p->ID,
                'title' => self::clean_title($p),
                'type' => get_post_meta($p->ID, '_elementor_template_type', true),
                'status' => $p->post_status,
            ];
        }
        return rest_ensure_response(['items' => $items]);
    }

    private static function walk(&$elements, &$items, $path = [], $depth = 0) {
        if (!is_array($elements)) return;
        foreach ($elements as $i => &$el) {
            $cur = array_merge($path, [$i]);
            $settings = isset($el['settings']) && is_array($el['settings']) ? $el['settings'] : [];
            $item = [
                'id' => $el['id'] ?? null,
                'elType' => $el['elType'] ?? null,
                'widgetType' => $el['widgetType'] ?? null,
                'depth' => $depth,
                'path' => $cur,
                'text' => [],
            ];
            foreach ($settings as $k => $v) {
                if (is_string($v) && trim(wp_strip_all_tags($v)) !== '') {
                    $item['text'][$k] = $v;
                }
            }
            if ($item['widgetType'] || !empty($item['text'])) $items[] = $item;
            if (!empty($el['elements']) && is_array($el['elements'])) {
                self::walk($el['elements'], $items, array_merge($cur, ['elements']), $depth + 1);
            }
        }
    }

    public static function structure($request) {
        $post_id = intval($request['id']);
        $post = self::post_check($post_id);
        if (is_wp_error($post)) return $post;
        $data = self::data($post_id);
        $items = [];
        self::walk($data, $items);
        return rest_ensure_response([
            'post_id' => $post_id,
            'title' => self::clean_title($post),
            'link' => get_permalink($post_id),
            'widget_count' => count($items),
            'items' => $items,
        ]);
    }

    private static function semantic($post_id) {
        $data = self::data($post_id);
        $items = [];
        self::walk($data, $items);

        $map = [
            'hero' => ['heading' => null, 'intro' => null, 'buttons' => []],
            'headings' => [],
            'text_blocks' => [],
            'cards' => [],
            'faqs' => [],
            'forms' => [],
            'all' => $items,
        ];

        $heading_index = 0;
        $pending_faq = null;

        foreach ($items as $item) {
            $wt = $item['widgetType'];
            $text = $item['text'];

            if ($wt === 'heading' && isset($text['title'])) {
                $heading_index++;
                $h = [
                    'id' => $item['id'],
                    'text' => $text['title'],
                    'setting' => 'title',
                    'depth' => $item['depth'],
                ];
                $map['headings'][] = $h;
                if (!$map['hero']['heading']) $map['hero']['heading'] = $h;

                $plain = trim(wp_strip_all_tags($text['title']));
                if (substr($plain, -1) === '?' || stripos($plain, 'how ') === 0 || stripos($plain, 'what ') === 0 || stripos($plain, 'why ') === 0) {
                    $pending_faq = ['question' => $h, 'answer' => null];
                }
            }

            if ($wt === 'text-editor' && isset($text['editor'])) {
                $t = [
                    'id' => $item['id'],
                    'html' => $text['editor'],
                    'setting' => 'editor',
                    'depth' => $item['depth'],
                ];
                $map['text_blocks'][] = $t;
                if (!$map['hero']['intro']) $map['hero']['intro'] = $t;
                if ($pending_faq && !$pending_faq['answer']) {
                    $pending_faq['answer'] = $t;
                    $map['faqs'][] = $pending_faq;
                    $pending_faq = null;
                }
            }

            if ($wt === 'icon-box') {
                $map['cards'][] = [
                    'id' => $item['id'],
                    'title' => $text['title_text'] ?? '',
                    'description' => $text['description_text'] ?? '',
                    'title_setting' => 'title_text',
                    'description_setting' => 'description_text',
                    'depth' => $item['depth'],
                ];
            }

            if ($wt === 'button') {
                $map['hero']['buttons'][] = [
                    'id' => $item['id'],
                    'text' => $text['text'] ?? '',
                    'setting' => 'text',
                ];
            }

            if ($wt === 'form') {
                $map['forms'][] = [
                    'id' => $item['id'],
                    'form_name' => $text['form_name'] ?? '',
                    'button_text' => $text['button_text'] ?? '',
                    'email_to' => $text['email_to'] ?? '',
                ];
            }
        }
        return $map;
    }

    public static function semantic_map($request) {
        $post_id = intval($request['id']);
        $post = self::post_check($post_id);
        if (is_wp_error($post)) return $post;
        return rest_ensure_response([
            'post_id' => $post_id,
            'title' => self::clean_title($post),
            'map' => self::semantic($post_id),
        ]);
    }

    private static function set_widget_setting(&$elements, $widget_id, $key, $value) {
        foreach ($elements as &$el) {
            if (($el['id'] ?? null) === $widget_id) {
                if (!isset($el['settings']) || !is_array($el['settings'])) $el['settings'] = [];
                $el['settings'][$key] = wp_kses_post($value);
                return true;
            }
            if (!empty($el['elements']) && is_array($el['elements'])) {
                if (self::set_widget_setting($el['elements'], $widget_id, $key, $value)) return true;
            }
        }
        return false;
    }

    public static function update_section_field($request) {
        $post_id = intval($request->get_param('post_id'));
        $section = sanitize_key($request->get_param('section'));
        $field = sanitize_key($request->get_param('field'));
        $value = (string) $request->get_param('value');
        $post = self::post_check($post_id);
        if (is_wp_error($post)) return $post;

        $map = self::semantic($post_id);
        $target = null;
        if ($section === 'hero' && $field === 'heading') $target = $map['hero']['heading'];
        if ($section === 'hero' && in_array($field, ['intro','text'], true)) $target = $map['hero']['intro'];

        if (!$target) return new WP_Error('not_found', 'Semantic field not found.', ['status' => 404]);

        $data = self::data($post_id);
        $ok = self::set_widget_setting($data, $target['id'], $target['setting'], $value);
        if (!$ok) return new WP_Error('not_updated', 'Could not update field.', ['status' => 400]);

        self::save_data($post_id, $data, "update {$section}.{$field}");
        return rest_ensure_response(['updated' => true, 'post_id' => $post_id, 'field' => "{$section}.{$field}", 'widget_id' => $target['id']]);
    }

    public static function update_card($request) {
        $post_id = intval($request->get_param('post_id'));
        $index = max(1, intval($request->get_param('index')));
        $title = $request->get_param('title');
        $description = $request->get_param('description');
        $post = self::post_check($post_id);
        if (is_wp_error($post)) return $post;

        $map = self::semantic($post_id);
        if (empty($map['cards'][$index - 1])) return new WP_Error('not_found', 'Card not found.', ['status' => 404]);
        $card = $map['cards'][$index - 1];

        $data = self::data($post_id);
        if ($title !== null) self::set_widget_setting($data, $card['id'], 'title_text', $title);
        if ($description !== null) self::set_widget_setting($data, $card['id'], 'description_text', $description);
        self::save_data($post_id, $data, "update card {$index}");

        return rest_ensure_response(['updated' => true, 'post_id' => $post_id, 'card_index' => $index, 'widget_id' => $card['id']]);
    }

    public static function update_faq($request) {
        $post_id = intval($request->get_param('post_id'));
        $index = max(1, intval($request->get_param('index')));
        $question = $request->get_param('question');
        $answer = $request->get_param('answer');
        $post = self::post_check($post_id);
        if (is_wp_error($post)) return $post;

        $map = self::semantic($post_id);
        if (empty($map['faqs'][$index - 1])) return new WP_Error('not_found', 'FAQ not found.', ['status' => 404]);
        $faq = $map['faqs'][$index - 1];

        $data = self::data($post_id);
        if ($question !== null) self::set_widget_setting($data, $faq['question']['id'], 'title', $question);
        if ($answer !== null) self::set_widget_setting($data, $faq['answer']['id'], 'editor', $answer);
        self::save_data($post_id, $data, "update faq {$index}");

        return rest_ensure_response(['updated' => true, 'post_id' => $post_id, 'faq_index' => $index]);
    }

    public static function replace_text($request) {
        $post_id = intval($request->get_param('post_id'));
        $old = (string) $request->get_param('old_text');
        $new = (string) $request->get_param('new_text');
        $post = self::post_check($post_id);
        if (is_wp_error($post)) return $post;
        if ($old === '') return new WP_Error('invalid', 'old_text is required.', ['status' => 400]);

        $data = self::data($post_id);
        $count = 0;
        self::replace_walk($data, $old, $new, $count);
        if (!$count) return new WP_Error('no_match', 'No matching text found.', ['status' => 404]);
        self::save_data($post_id, $data, 'replace text');

        return rest_ensure_response(['updated' => true, 'post_id' => $post_id, 'replacements' => $count]);
    }

    private static function replace_walk(&$elements, $old, $new, &$count) {
        foreach ($elements as &$el) {
            if (!empty($el['settings']) && is_array($el['settings'])) {
                foreach ($el['settings'] as $k => &$v) {
                    if (is_string($v) && strpos($v, $old) !== false) {
                        $v = str_replace($old, wp_kses_post($new), $v);
                        $count++;
                    }
                }
            }
            if (!empty($el['elements']) && is_array($el['elements'])) self::replace_walk($el['elements'], $old, $new, $count);
        }
    }

    public static function duplicate_page($request) {
        $source_id = intval($request->get_param('post_id'));
        $title = sanitize_text_field($request->get_param('title') ?: '');
        $slug = sanitize_title($request->get_param('slug') ?: '');
        $status = sanitize_key($request->get_param('status') ?: 'draft');
        return self::duplicate_post_like($source_id, $title, $slug, $status);
    }

    public static function create_service_page($request) {
        $source_id = intval($request->get_param('source_id'));
        $title = sanitize_text_field($request->get_param('title'));
        $slug = sanitize_title($request->get_param('slug') ?: $title);
        $status = sanitize_key($request->get_param('status') ?: 'draft');
        if (!$title) return new WP_Error('invalid', 'title is required.', ['status' => 400]);
        $result = self::duplicate_post_like($source_id, $title, $slug, $status);
        if (is_wp_error($result)) return $result;
        $data = $result->get_data();
        if ($request->get_param('seo_title') || $request->get_param('meta_description') || $request->get_param('focus_keyphrase')) {
            self::update_yoast(new WP_REST_Request('POST', '/dummy', [
                'post_id' => $data['new_id'],
                'seo_title' => $request->get_param('seo_title'),
                'meta_description' => $request->get_param('meta_description'),
                'focus_keyphrase' => $request->get_param('focus_keyphrase'),
            ]));
        }
        return $result;
    }

    private static function duplicate_post_like($source_id, $title = '', $slug = '', $status = 'draft') {
        $source = self::post_check($source_id);
        if (is_wp_error($source)) return $source;
        if (!$title) $title = $source->post_title . ' Copy';
        $postarr = [
            'post_title' => $title,
            'post_content' => $source->post_content,
            'post_excerpt' => $source->post_excerpt,
            'post_status' => in_array($status, ['draft','publish','private','pending'], true) ? $status : 'draft',
            'post_type' => $source->post_type,
            'post_parent' => $source->post_parent,
            'menu_order' => $source->menu_order,
            'post_author' => get_current_user_id(),
        ];
        if ($slug) $postarr['post_name'] = $slug;
        $new_id = wp_insert_post($postarr, true);
        if (is_wp_error($new_id)) return $new_id;

        foreach (get_post_meta($source_id) as $key => $values) {
            if (in_array($key, ['_edit_lock','_edit_last','_yellowstep_editor_snapshot'], true)) continue;
            foreach ($values as $value) add_post_meta($new_id, $key, maybe_unserialize($value));
        }
        self::clear_elementor_cache($new_id);
        return rest_ensure_response([
            'source_id' => $source_id,
            'new_id' => $new_id,
            'title' => self::clean_title(get_post($new_id)),
            'status' => get_post_status($new_id),
            'edit_link' => get_edit_post_link($new_id, 'raw'),
            'permalink' => get_permalink($new_id),
        ]);
    }

    public static function update_yoast($request) {
        $post_id = intval($request->get_param('post_id'));
        $post = self::post_check($post_id);
        if (is_wp_error($post)) return $post;

        foreach ([
            'seo_title' => '_yoast_wpseo_title',
            'meta_description' => '_yoast_wpseo_metadesc',
            'focus_keyphrase' => '_yoast_wpseo_focuskw',
        ] as $param => $meta_key) {
            $v = $request->get_param($param);
            if ($v !== null) update_post_meta($post_id, $meta_key, sanitize_text_field($v));
        }
        return rest_ensure_response([
            'updated' => true,
            'post_id' => $post_id,
            'seo_title' => get_post_meta($post_id, '_yoast_wpseo_title', true),
            'meta_description' => get_post_meta($post_id, '_yoast_wpseo_metadesc', true),
            'focus_keyphrase' => get_post_meta($post_id, '_yoast_wpseo_focuskw', true),
        ]);
    }

    public static function snapshots($request) {
        $post_id = intval($request['id']);
        $post = self::post_check($post_id);
        if (is_wp_error($post)) return $post;
        $snaps = get_post_meta($post_id, '_yellowstep_editor_snapshot');
        $items = [];
        foreach ($snaps as $i => $s) {
            $items[] = ['index' => $i, 'time' => $s['time'] ?? '', 'note' => $s['note'] ?? '', 'user_id' => $s['user_id'] ?? ''];
        }
        return rest_ensure_response(['post_id' => $post_id, 'snapshots' => $items]);
    }

    public static function rollback($request) {
        $post_id = intval($request->get_param('post_id'));
        $index = $request->get_param('index');
        $post = self::post_check($post_id);
        if (is_wp_error($post)) return $post;
        $snaps = get_post_meta($post_id, '_yellowstep_editor_snapshot');
        if (empty($snaps)) return new WP_Error('not_found', 'No snapshots found.', ['status' => 404]);
        $snap = ($index === null) ? end($snaps) : ($snaps[intval($index)] ?? null);
        if (!$snap || !isset($snap['data'])) return new WP_Error('not_found', 'Snapshot not found.', ['status' => 404]);
        update_post_meta($post_id, '_elementor_data', wp_slash($snap['data']));
        self::clear_elementor_cache($post_id);
        return rest_ensure_response(['rolled_back' => true, 'post_id' => $post_id]);
    }

    public static function regenerate_css($request) {
        $post_id = intval($request->get_param('post_id') ?: 0);
        self::clear_elementor_cache($post_id);
        return rest_ensure_response(['regenerated' => true, 'post_id' => $post_id]);
    }
}

Yellowstep_Elementor_Editor::init();
