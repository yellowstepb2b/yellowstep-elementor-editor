# Yellowstep Elementor Editor v1.0.0

Semantic Elementor editing helper for the Yellowstep WP Engine development site.

## What this adds

Authenticated REST endpoints under:

`/wp-json/yellowstep-editor/v1/`

## Key endpoints

- `GET /pages`
- `GET /templates`
- `GET /structure/{id}`
- `GET /semantic-map/{id}`
- `POST /duplicate-page`
- `POST /create-service-page`
- `POST /update-section-field`
- `POST /update-card`
- `POST /update-faq`
- `POST /replace-text`
- `POST /update-yoast`
- `GET /snapshots/{id}`
- `POST /rollback`
- `POST /regenerate-css`

## Safety

Before Elementor data is changed, the current `_elementor_data` is saved to:

`_yellowstep_editor_snapshot`

This enables rollback.
